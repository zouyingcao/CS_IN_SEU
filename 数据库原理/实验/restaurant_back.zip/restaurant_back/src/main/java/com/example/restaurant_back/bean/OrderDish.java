package com.example.restaurant_back.bean;

public class OrderDish {
    private Integer orderId;

    private String name;

    private Integer amount;

    private Double price;

    private Boolean cooking;

    private Boolean finish;

    public Integer getOrderId() {
        return orderId;
    }

    public void setOrderId(Integer orderId) {
        this.orderId = orderId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name == null ? null : name.trim();
    }

    public Integer getAmount() {
        return amount;
    }

    public void setAmount(Integer amount) {
        this.amount = amount;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public Boolean getCooking() {
        return cooking;
    }

    public void setCooking(Boolean cooking) {
        this.cooking = cooking;
    }

    public Boolean getFinish() {
        return finish;
    }

    public void setFinish(Boolean finish) {
        this.finish = finish;
    }
}