package com.example.restaurant_back.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

@RestController
public class CookController {

    @RequestMapping("/getreservedishes")
    public ArrayList<Map<String,String>> getReserveDishes()
    {
        System.out.println("开始传输”后厨订单“数据");
        ArrayList<Map<String,String>> postsAll=new ArrayList<>();
        postsAll.add(new HashMap<String,String>(){
            {
                put("f1", "宫爆鸡丁 水饺 扬州炒饭 紫菜蛋花汤");
                put("f2", "2021/7/24");
            }
        });
        postsAll.add(new HashMap<String,String>(){{
            put("f1", "宫爆鸡丁 水饺 扬州炒饭 紫菜蛋花汤");
            put("f2", "2021/7/24");

        }});


        return postsAll;
    }
}
