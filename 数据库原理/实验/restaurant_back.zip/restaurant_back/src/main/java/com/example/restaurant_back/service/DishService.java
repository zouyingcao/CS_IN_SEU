package com.example.restaurant_back.service;

import com.example.restaurant_back.bean.Dish;

import java.util.List;

public interface DishService {
    public List<Dish> findMainCourse();
    public List<Dish> findDrink();
    public List<Dish> findSnack();
}
