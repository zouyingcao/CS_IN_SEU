package com.example.restaurant_back.service;

import com.example.restaurant_back.bean.Order;
import com.example.restaurant_back.bean.OrderDish;

import java.util.List;

public interface OrderService {
    public int generateOrderId();
    public int addOrder(String userName,int tableId,int person,double cost, List<OrderDish>dishList);
}
