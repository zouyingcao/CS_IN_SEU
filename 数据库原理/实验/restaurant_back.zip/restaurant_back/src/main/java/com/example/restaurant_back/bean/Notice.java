package com.example.restaurant_back.bean;

public class Notice {
    private Integer noticeId;

    private Integer fromAdmin;

    private String text;

    public Integer getNoticeId() {
        return noticeId;
    }

    public void setNoticeId(Integer noticeId) {
        this.noticeId = noticeId;
    }

    public Integer getFromAdmin() {
        return fromAdmin;
    }

    public void setFromAdmin(Integer fromAdmin) {
        this.fromAdmin = fromAdmin;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text == null ? null : text.trim();
    }
}