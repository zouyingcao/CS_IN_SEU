package com.example.restaurant_back.controller;

import com.example.restaurant_back.bean.Dish;
import com.example.restaurant_back.serviceImpl.DishServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.*;

@RestController
@CrossOrigin
public class DishController {

    @Autowired
    private DishServiceImpl dishService;

    @RequestMapping("/getMainCourse")
    public List<Dish> getMainCourse()
    {
        System.out.println("收到请求，正在获取主菜");
//        System.out.println("获取到主菜："+dishService.findMainCourse());
        return dishService.findMainCourse();
    }

    @RequestMapping("/getDrink")
    public List<Dish>getDrink()
    {
        System.out.println("收到请求，正在获取饮料");
        return dishService.findDrink();
    }

    @RequestMapping("/getSnack")
    public List<Dish>getSnack()
    {
        System.out.println("收到请求，正在获取小吃");
        return dishService.findSnack();
    }

}
