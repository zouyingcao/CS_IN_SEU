package com.example.restaurant_back.controller;


import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

@RestController
public class WaiterController {
    @RequestMapping("/getservedishes")
    public ArrayList<Map<String,String>> getServeDishes()
    {
        System.out.println("开始传输”服务员上菜“数据");
        ArrayList<Map<String,String>> postsAll=new ArrayList<>();
        postsAll.add(new HashMap<String,String>(){
            {
                put("f1", "宫爆鸡丁 第五桌");
                put("f2", "2021/7/24");
            }
        });
        postsAll.add(new HashMap<String,String>(){{
            put("f1", " 水饺 第七桌");
            put("f2", "2021/7/24");

        }});


        return postsAll;
    }
}
