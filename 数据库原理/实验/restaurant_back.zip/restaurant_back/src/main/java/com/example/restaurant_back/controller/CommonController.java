package com.example.restaurant_back.controller;


import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

@RestController
public class CommonController {
    @GetMapping(path="getpersoninfo")
    public Map<String,String> getTest()
    {
        System.out.println("开始传输”个人信息“数据");
        HashMap<String,String> test=new HashMap<>();
        test.put("imageUrl", "https://img1.baidu.com/it/u=1129551767,2230146464&fm=26&fmt=auto&gp=0.jpg");
        test.put("email", "571699954@qq.com");
        test.put("address", "东南大学");
        test.put("name", " 陈旭");
        test.put("phonenum", "18650098538");
        test.put("id", "233333");
        test.put("registerdate", "233333");
        return test;
    }
    @GetMapping(path="checknotice")
    public ArrayList<Map<String,String>> getLostAndFound2()
    {
        System.out.println("开始传输”查看公告“数据");
        ArrayList<Map<String,String>> postsAll=new ArrayList<>();
        postsAll.add(new HashMap<String,String>(){
            {
                put("f1", "八点了，该摸了");
                put("f2", "不知道说什么");
            }
        });
        postsAll.add(new HashMap<String,String>(){{
            put("f1", "钟离");
            put("f2", "详情");

        }});


        return postsAll;
    }
    @RequestMapping("/getorderdetail")
    public ArrayList<Map<String,String>> getOrderDetail()
    {
        System.out.println("开始传输”订单详情“数据");
        ArrayList<Map<String,String>> postsAll=new ArrayList<>();
        postsAll.add(new HashMap<String,String>(){
            {

                put("name", "宫保鸡丁");
                put("num", "2");
                put("price", "5.00");
                put("cost","10.00" );
            }
        });



        return postsAll;
    }
}
