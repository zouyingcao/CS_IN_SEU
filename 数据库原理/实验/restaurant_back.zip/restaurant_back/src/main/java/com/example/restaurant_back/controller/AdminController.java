package com.example.restaurant_back.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;


@RestController

public class AdminController {
    @RequestMapping("/postmanagenotice")
    public int nptices(@RequestParam(value = "f1") String f1, @RequestParam(value = "f2") String f2)
    {
        System.out.println("接收到管理公告请求");

        System.out.println("数据载入完毕，准备注册" +f1+f2);

        return 1;
    }

    @RequestMapping("/getmanagenotice")
    public ArrayList<Map<String,String>> getNotice()
    {
        System.out.println("开始传输”公告管理“数据");
        ArrayList<Map<String,String>> postsAll=new ArrayList<>();
        postsAll.add(new HashMap<String,String>(){
            {
                put("f1", "八点了，该摸了");
                put("f2", "2021/7/24");
            }
        });
        postsAll.add(new HashMap<String,String>(){{
            put("f1", "摸了");
            put("f2", "2021/7/24");

        }});


        return postsAll;
    }
    @RequestMapping("/getmanagestaff")
    public ArrayList<Map<String,String>> getStaff()
    {
        System.out.println("开始传输”员工管理“数据");
        ArrayList<Map<String,String>> postsAll=new ArrayList<>();
        postsAll.add(new HashMap<String,String>(){
            {
                put("name", "打工人1");
                put("job", "服务员");
                put("id","71119" );
                put("account","yangqiang" );
                put("password","yang123" );
            }
        });
        postsAll.add(new HashMap<String,String>(){
            {
                put("name", "打工人2");
                put("job", "服务员");
                put("id","71119" );
                put("account","qiangyang" );
                put("password","qiang123" );
            }
        });


        return postsAll;
    }
    @RequestMapping("/getmanagedata")
    public ArrayList<Map<String,String>> getManageData()
    {
        System.out.println("开始传输”经营数据查看“数据");
        ArrayList<Map<String,String>> postsAll=new ArrayList<>();
        postsAll.add(new HashMap<String,String>(){
            {
                put("date", "2021-07-03");
                put("name", "admin");
                put("orderquantities", "100");
                put("unusual","否" );
                put("income","66666" );
                put("comfirm","已确认" );
            }
        });
        postsAll.add(new HashMap<String,String>(){
            {
                put("date", "2021-07-03");
                put("name", "admin");
                put("orderquantities", "100");
                put("unusual","否" );
                put("income","66666" );
                put("comfirm","已确认" );
            }
        });
        postsAll.add(new HashMap<String,String>(){
            {
                put("date", "2021-07-03");
                put("name", "admin");
                put("orderquantities", "100");
                put("unusual","否" );
                put("income","66666" );
                put("comfirm","已确认" );
            }
        });
        postsAll.add(new HashMap<String,String>(){
            {
                put("date", "2021-07-03");
                put("name", "admin");
                put("orderquantities", "100");
                put("unusual","否" );
                put("income","66666" );
                put("comfirm","已确认" );
            }
        });


        return postsAll;
    }
    @RequestMapping("/getmanagedishes")
    public ArrayList<Map<String,String>> getManageDishes()
    {
        System.out.println("开始传输”菜品管理“数据");
        ArrayList<Map<String,String>> postsAll=new ArrayList<>();
        postsAll.add(new HashMap<String,String>(){
            {
                put("name", "宫保鸡丁");
                put("price", "5.00");
                put("describe","123" );
            }
        });



        return postsAll;
    }
}
