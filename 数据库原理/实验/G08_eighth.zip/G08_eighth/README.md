# restaurant

### 如遇到TypeError: this.getOptions is not a function报错

```
npm uninstall --save sass-loader // 卸载
npm i -D sass-loader@8.x // 安装
npm uninstall --save node-sass // 卸载
npm i node-sass@4.14.1 // 安装
```

### 若未安装base64

```
npm install --save js-base64
```

### vue添加图片方法

```html
<el-image
style="width: 100%; height:100%; margin:0px 0px 0px 0px;"
:src="require('../assets/img/login-bg.jpg')"
/>
```

### 若未安装vuex

```
npm install --save vuex
npm install --save vuex-persistedstate
```

