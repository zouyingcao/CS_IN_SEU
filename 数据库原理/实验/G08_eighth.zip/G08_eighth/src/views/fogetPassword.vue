<template>
  <div>
    忘记密码
  </div>
</template>
